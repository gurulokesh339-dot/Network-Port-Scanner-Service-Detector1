import http.server
import socketserver
import os
import webbrowser
import time

PORT = 9999
BASE_DIR = r"C:\network_port_scanner"
ZIP_FILE = r"C:\Users\gurul\Downloads\network_port_scanner.zip"
if not os.path.exists(ZIP_FILE):
    ZIP_FILE = os.path.join(BASE_DIR, "network_port_scanner.zip")

HTML_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Download Project Files - CyberScope</title>
<style>
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background-color: #0f172a;
    color: #f8fafc;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
  }
  .card {
    background: #1e293b;
    border: 1px solid #334155;
    border-radius: 16px;
    padding: 32px;
    max-width: 550px;
    width: 90%;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    text-align: center;
  }
  h1 { font-size: 22px; margin-bottom: 8px; color: #38bdf8; }
  p { font-size: 14px; color: #94a3b8; margin-bottom: 24px; }
  .btn-download {
    display: block;
    background: linear-gradient(135deg, #0284c7, #2563eb);
    color: white;
    text-decoration: none;
    padding: 14px 20px;
    border-radius: 10px;
    font-size: 15px;
    font-weight: bold;
    margin-bottom: 12px;
    transition: transform 0.15s, opacity 0.15s;
  }
  .btn-download:hover { opacity: 0.95; transform: translateY(-2px); }
  .btn-secondary {
    display: block;
    background: #334155;
    color: #f1f5f9;
    text-decoration: none;
    padding: 12px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .btn-secondary:hover { background: #475569; }
  .badge { background: #0369a1; padding: 2px 6px; border-radius: 4px; font-size: 11px; margin-left: 6px; }
</style>
</head>
<body>
<div class="card">
  <h1>📦 CyberScope Project Downloads</h1>
  <p>Click any button below to download the file directly through your browser:</p>
  
  <a href="/download/zip" class="btn-download">
    ⬇️ Download Full Project ZIP <span class="badge">All Code + Report</span>
  </a>
  
  <a href="/download/pdf" class="btn-secondary">
    📄 Download Project Report (PDF)
  </a>
  
  <a href="/download/scanner" class="btn-secondary">
    🐍 Download scanner.py (Python Script)
  </a>

  <a href="/download/web_app" class="btn-secondary">
    🌐 Download web_app.py (Web Dashboard)
  </a>

  <a href="/download/readme" class="btn-secondary">
    📖 Download README.md (Documentation)
  </a>
</div>
</body>
</html>
"""

class DownloadHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode("utf-8"))

        elif self.path == "/download/zip":
            self.serve_file(ZIP_FILE, "network_port_scanner.zip", "application/zip")

        elif self.path == "/download/pdf":
            pdf_path = os.path.join(BASE_DIR, "PROJECT_REPORT.pdf")
            self.serve_file(pdf_path, "PROJECT_REPORT.pdf", "application/pdf")

        elif self.path == "/download/scanner":
            scanner_path = os.path.join(BASE_DIR, "scanner.py")
            self.serve_file(scanner_path, "scanner.py", "text/x-python")

        elif self.path == "/download/web_app":
            web_path = os.path.join(BASE_DIR, "web_app.py")
            self.serve_file(web_path, "web_app.py", "text/x-python")

        elif self.path == "/download/readme":
            readme_path = os.path.join(BASE_DIR, "README.md")
            self.serve_file(readme_path, "README.md", "text/markdown")
        else:
            self.send_error(404, "File Not Found")

    def serve_file(self, filepath, download_name, mime_type):
        if os.path.exists(filepath):
            with open(filepath, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", mime_type)
            self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_error(404, f"File {download_name} not found on server")

    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    PORT = 9998
    with socketserver.TCPServer(("127.0.0.1", PORT), DownloadHandler) as httpd:
        print(f"Download server active on port {PORT}")
        httpd.serve_forever()
